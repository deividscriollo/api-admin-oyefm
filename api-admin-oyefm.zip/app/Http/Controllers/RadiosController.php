<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
// Extras
use DB;

class RadiosController extends Controller
{
   public function Get_Radios(Request $request){
   	$radios=DB::table('radios')->orderBy('nombre','ASC')->get();
	return response()->json(['respuesta'=>$radios]);

   }
}
